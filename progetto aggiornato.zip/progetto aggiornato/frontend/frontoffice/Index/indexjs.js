const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.getElementById('container');

signUpButton.addEventListener('click', () => {
	container.classList.add("right-panel-active");
});

signInButton.addEventListener('click', () => {
	container.classList.remove("right-panel-active");
});

// parte login
//PRIMO LOGIN NON FUNZIONA
document.getElementById("login").addEventListener("click",async ()=>{
	console.log("LOGIN IN CORSO")

	var user = document.getElementById("usernameLogin").value
	var pwd = document.getElementById("passwordLogin").value

	var response = await fetch("http://127.0.0.1:8081/login",{ // await fetch aspetta che risponda server e struttura della chiamata che arriva al server
		method: "POST",
		headers:{
			"Content-type":"application/json"
		},
		body: JSON.stringify(
			{
				user:{
					username: user,
					password: pwd
				}
			}
		)
	})
	if(response.status == 200){
		console.log("LOGIN EFFETTUATO CORRETTAMENTE")
		var data = await response.json() // await del json
		console.log(data)
		if(data.type=="normal"){
			window.location.href="../Logged/logged.html"  //redirect
		}
		else if (data.type=="admin"){
			window.location.href="../Back-Office/BackOffice.html"  //redirect
		}
		

		
	}else{
		console.log(response.status)
	}
})

document.getElementById("register").addEventListener("click",async ()=>{
	console.log("REGISTRAZIONE IN CORSO")

	var user = document.getElementById("usernameRegister").value
	var eml = document.getElementById("emailRegister").value
	var pwd = document.getElementById("passwordRegister").value

	var response = await fetch("http://127.0.0.1:8081/register",{
		method: "POST",
		headers:{
			"Content-type":"application/json"
		},
		body: JSON.stringify(
			{
				user:{
					username: user,
					email: eml,
					password: pwd
				}
			}
		)
	})
	if(response.status == 200){
		console.log("REGISTRAZIONE EFFETTUATA CORRETTAMENTE")
		var data = await response.json() // await del json
		console.log(data)
		if(!data){
			//da mettere label (email o user già usato)
		}else if(data.type=="normal"){
			window.location.href="../Logged/logged.html"  //redirect
		}
		
		

		
	}else{
		console.log(response.status)
	}
})