function saveNickname(){
    if(document.getElementById("nickname").value){
        window.localStorage.setItem('name', document.getElementById("nickname").value);
        window.location.href='../GamePage/GamePage.html'; 
    }
    

    
}
