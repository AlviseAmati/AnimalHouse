function getNickname(){

    document.getElementById("nickname").innerHTML += window.localStorage.getItem('name');

}