let data;

async function getData(){
    
    var response0 = await fetch("https://zoo-animal-api.herokuapp.com/animals/rand");
    var data0 = await response0.json();
    var response1 = await fetch("https://zoo-animal-api.herokuapp.com/animals/rand");
    var data1 = await response1.json();
    var response2 = await fetch("https://zoo-animal-api.herokuapp.com/animals/rand");
    var data2 = await response2.json();
    var response3 = await fetch("https://zoo-animal-api.herokuapp.com/animals/rand");
    var data3 = await response3.json();
    data = [data0,data1,data2,data3]
    if(response0.status == 200 && response1.status == 200 && response2.status == 200 && response3.status == 200){
        document.querySelector("body > img").src = data0.image_link;
        var random = Math.floor(Math.random() * (3 - 0 + 1) ) + 0;
        for(var i = 0; i < 4; i++){
            document.querySelector("#label" + random + "").innerHTML = data[i].name;
            document.querySelector("#answer" + random + "").value = data[i].name;
            if(random == 3){
                random = 0;
            }else{
                random++;
            }
        }
    }
    document.querySelector("#result").innerHTML = "";
    uncheckedRadioButtons();
}

function getResult(){
    for(radioButton of document.querySelectorAll("input")){
        if(radioButton.checked){
            if(radioButton.value == (data[0].name)){
                document.querySelector("#result").innerHTML = "RISPOSTA CORRETTA";
            }else{
                document.querySelector("#result").innerHTML = "RISPOSTA SBAGLIATA";
            }
        }
    }
}

function uncheckedRadioButtons(){
    for(radioButton of document.querySelectorAll("input")){
        if(radioButton.checked){
            radioButton.checked = false;
        }
    }
}
    