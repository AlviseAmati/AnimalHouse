// creazione server node e parte login con file json
const express = require('express')
const req = require('express/lib/request')
const res = require('express/lib/response')
const fs = require("fs")
const cors = require("cors")


const app = express()
const port = 8081

const path = require('path')

const bodyParser = require('body-parser')
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())
app.use(cors())
app.use('/public', express.static('public'))


const json = fs.readFileSync("user.json", "utf8");  
const data = JSON.parse(json); 

app.post('/login',(req,res) => { 
  const {user} = req.body; 
  console.log(req.body)
  console.log(user)

  if(user){
    for(var usr of data.users){
      if(usr.username == user.username && usr.password == user.password){
        res.json({ 
          username: usr.username,  
          type: usr.type
        })
        return
      }
    }
    res.sendStatus(401)
  }else{
    res.sendStatus(400)
  }
})

app.post('/register',(req,res) => { 
  const {user} = req.body; 
  console.log(req.body)
  console.log(user)

  if(user){
    for(var usr of data.users){
      if(usr.username == user.username || usr.email == user.email ){  
        return 
      }else {
        let newUser = {username: user.username,password: user.password ,email: user.email, type: "normal"};
        data.users.push(newUser);
        fs.writeFileSync("user.json", JSON.stringify(data));
        res.json({ 
          username: usr.username,  
          type: usr.type
        })
        return
      }
    }
    res.sendStatus(401)
  }else{
    res.sendStatus(400)
  }
})

app.get('/loadEcommerce',(req,res) => {  

  const json = fs.readFileSync("ecommerce.json", "utf8");  
  const data = JSON.parse(json);

  if(data.items){
    res.json({ 
      items : data.items
    })
    return
  }else{
    res.sendStatus(400)
  }
})

app.get('/getUsers',(req,res) => {
  if(data.users){
    res.json({
      users: data.users
    })
  }else{
    res.sendStatus(400)
  }
})




app.listen(port, () => { 
    console.log("Express in ascolto su porta " + port)
  })



  
  // per startaer server vado dentro backend in terminal e faccio node server.js