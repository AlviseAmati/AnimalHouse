// creazione server node e parte login con file json
const express = require('express')
const req = require('express/lib/request')
const res = require('express/lib/response')
const fs = require("fs")
const cors = require("cors")


const app = express()
const port = 8081

const path = require('path')

const bodyParser = require('body-parser')
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())
app.use(cors())
app.use('/public', express.static('public'))


const json = fs.readFileSync("user.json", "utf8");  
const data = JSON.parse(json); 

app.post('/login',(req,res) => { 
  const {user} = req.body; 
  console.log(req.body)
  console.log(user)

  if(user){
    for(var usr of data.users){
      if(usr.username == user.username && usr.password == user.password){
        res.json({ 
          username: usr.username,  
          type: usr.type
        })
        return
      }
    }
    res.sendStatus(401)
  }else{
    res.sendStatus(400)
  }
})

app.post('/register',(req,res) => { 
  const {user} = req.body; 
  console.log(req.body)
  console.log(user)

  if(user){
    for(var usr of data.users){
      if(usr.username == user.username || usr.email == user.email ){  
        return 
      }
    }
    let newUser = {username: user.username,password: user.password ,email: user.email, type: "normal"};
        data.users.push(newUser);
        fs.writeFileSync("user.json", JSON.stringify(data));
        res.json({ 
          username: usr.username,  
          type: usr.type
        })
        return
  }else{
    res.sendStatus(400)
  }
})

app.get('/loadEcommerce',(req,res) => {  

  const json = fs.readFileSync("ecommerce.json", "utf8");  
  const data = JSON.parse(json);
  if(data.items){
    res.json({ 
      items : data.items
    })
    return
  }else{
    res.sendStatus(400)
  }
})

app.get('/getUsers',(req,res) => {
  if(data.users){
    res.json({
      users: data.users
    })
  }else{
    res.sendStatus(400)
  }
})

app.post('/addScore',(req,res) => {
  const json = fs.readFileSync("leaderboard.json", "utf8");  
  const data = JSON.parse(json);
  console.log("Tentativo di aggiunta score")
  const {value} = req.body;
  console.log(value.score);
  console.log(value.name);


  if(value){
    var min = 9999;
    var pos;
    var add = true;
    if(value.type == "quiz"){
      console.log(data.quiz.length);
      if(data.quiz.length >= 10){
        for(var valuePos in data.quiz){
          if(min > data.quiz[valuePos].score){
            min =  data.quiz[valuePos].score;
            pos = valuePos;
          }
        }
        if(min < value.score){
          data.quiz.splice(pos,1);
        }else{
          add = false;
        }
      }if(add == true){
        let newValue = {name: value.name,score: value.score};
        data.quiz.push(newValue);
        fs.writeFileSync("leaderboard.json", JSON.stringify(data));
      }
    }else if(value.type == "memory"){
      if(data.memory.length >= 10){
        for(var valuePos in data.memory){
          if(min > data.memory[valuePos].score){
            min =  data.memory[valuePos].score;
            pos = valuePos;
          }
        }
        if(min < value.score){
          data.memory.splice(pos,1);
        }else{
          add = false;
        }
      }
      if(add == true){
        let newValue = {name: value.name,score: value.score};
        data.memory.push(newValue);
        fs.writeFileSync("leaderboard.json", JSON.stringify(data));
      }
    }
    res.sendStatus(200);
  }
})

app.get('/getLeaderboards',(req,res) => {

  console.log("Invio leaderboards")
  const json = fs.readFileSync("leaderboard.json", "utf8");  
  const data = JSON.parse(json);
  data.quiz.sort((a, b) => b.score - a.score ); 
  data.memory.sort((a, b) => b.score - a.score);

  if(data.quiz && data.memory){
    res.json({
      quiz: data.quiz,
      memory: data.memory
    })
  }else{
    res.sendStatus(400)
  }
})

app.post('/addItem',(req,res) => {
  const json = fs.readFileSync("ecommerce.json", "utf8");  
  const data = JSON.parse(json);
  console.log("Tentativo di aggiunta item")

  const {item} = req.body;
  if(item){
    for(var itm of data.items){
      if(item.name == itm.name){
        return;
      }
    }
    let newItem = {name: item.name,description: item.description ,price: item.price, img: item.image, category: item.category};
    data.items.push(newItem);
    fs.writeFileSync("ecommerce.json", JSON.stringify(data));
    res.sendStatus(200);
    console.log(newItem);
  }
})

app.delete('/removeItem',(req,res) => {
  const json = fs.readFileSync("ecommerce.json", "utf8");  
  const data = JSON.parse(json);
  console.log("Tentativo di rimozione item")
  const item = req.body;
  if(item){
    for(var itmPos in data.items){
      if(item.name == data.items[itmPos].name){
        data.items.splice(itmPos,1);
        break;
      }
    }
    fs.writeFileSync("ecommerce.json", JSON.stringify(data));
    res.sendStatus(200);
  }
})

app.get('/getPosts',(req,res) => {
  const json = fs.readFileSync("dashboard.json", "utf8");  
  const data = JSON.parse(json);
  console.log("get post")

  if(data.posts){
    res.json({
      posts: data.posts
    })
  }else{
    res.sendStatus(400)
  }

})

app.post('/addPost',(req,res) => {
  const json = fs.readFileSync("dashboard.json", "utf8");  
  const data = JSON.parse(json);
  console.log("Tentativo di aggiunta post")

  const {post} = req.body;
  if(post){
    let newPost = {username: post.username,text: post.text ,image: post.image, title: post.title};
    data.posts.push(newPost);
    fs.writeFileSync("dashboard.json", JSON.stringify(data));
    res.sendStatus(200);
  }
})




app.listen(port, () => { 
    console.log("Express in ascolto su porta " + port)
  })



  
  