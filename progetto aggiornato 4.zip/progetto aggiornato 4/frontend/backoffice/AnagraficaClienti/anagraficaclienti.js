async function getUsers(){
    var response = await fetch("http://127.0.0.1:8081/getUsers",{
		method: "GET",
		headers:{
			"Content-type":"application/json"
		}
	})
	if(response.status == 200){
		console.log("DATI CARICATI CORRETTAMENTE")
		var data = await response.json() // await del json
		console.log(data.users)
		for(user of data.users){
            document.querySelector(".users").innerHTML += `
            <div class="user">
                <div>Username: ${user.username} </div>
                <div>Email: ${user.email} </div>
                <div>Type: ${user.type} </div>
                <button> Change Password </button>
                <button> Reset Password </button>
                <button> Delete User </button>
            </div>

            `
        }
		

		
	}else{
		console.log(response.status)
	}
}

